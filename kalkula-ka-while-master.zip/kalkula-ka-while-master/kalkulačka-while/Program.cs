﻿using System;

namespace kalkulačka_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            i = 0;
            while (i <= 0)
            {
                Console.WriteLine("výtej v programu");
                Console.WriteLine("Hello, World!");
                Console.WriteLine("zadejte první číslo");
                string input = Console.ReadLine();
                double number = Convert.ToDouble(input);

                Console.WriteLine("Zadejte druhé číslo");
                string input2 = Console.ReadLine();
                double number2 = Convert.ToDouble(input2);

                Console.WriteLine("Zvolte si možnost");
                Console.WriteLine("1. součet");
                Console.WriteLine("2. rozdíl");
                Console.WriteLine("3. součin");
                Console.WriteLine("4. podíl");

                string input3 = Console.ReadLine();
                int menu = Convert.ToInt32(input3);
                double result = 0;
                switch (menu)
                {
                    case 1:
                        result = number + number2;
                        Console.WriteLine(result);
                        break;

                    case 2:
                        result = number - number2;
                        Console.WriteLine(result);
                        break;

                    case 3:
                        result = number * number2;
                        Console.WriteLine(result);
                        break;

                    case 4:
                        result = number / number2;
                        Console.WriteLine(result);
                        break;
                }
                Console.WriteLine("chcete počítat znovu?");
                Console.WriteLine("Stiskněte 1 pro opakování programu");
                Console.WriteLine("Stiskněte 2 pro ukončení programu");
                string input4;
                input4 = Console.ReadLine();
                int a = Convert.ToInt16(input4);

                if (a >= 1)
                    i = 1;

                Console.WriteLine();
                Console.WriteLine("program ukončen");
                Console.ReadKey();
            }
        }
    }
}
